package com.example.productmanagement

data class Product(
    var name: String = "",
    var price: String = "",
    var quantity: String = "",
    var id: String = ""
)
