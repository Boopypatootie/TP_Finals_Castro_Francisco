package com.example.productmanagement

import android.os.Bundle
import android.view.View
import android.widget.*
import com.example.productmanagement.R
import androidx.appcompat.app.AppCompatActivity
import androidx.recyclerview.widget.LinearLayoutManager
import androidx.recyclerview.widget.RecyclerView
import com.example.productmanagement.Product
import com.example.productmanagement.ProductAdapter
import com.google.firebase.database.*
import com.google.firebase.database.ktx.database
import com.google.firebase.ktx.Firebase


class MainActivity : AppCompatActivity() {

    private lateinit var productRef: DatabaseReference
    private lateinit var productList: MutableList<Product>
    private lateinit var adapter: ProductAdapter

    private lateinit var nameInput: EditText
    private lateinit var priceInput: EditText
    private lateinit var quantityInput: EditText
    private lateinit var saveButton: Button
    private lateinit var updateButton: Button
    private lateinit var deleteButton: Button
    private var selectedProductId: String? = null

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        setContentView(R.layout.activity_main)

        // Firebase setup
        productRef = Firebase.database.getReference("products")

        // Bind views
        nameInput = findViewById(R.id.productNameInput)
        priceInput = findViewById(R.id.priceInput)
        quantityInput = findViewById(R.id.quantityInput)
        saveButton = findViewById(R.id.saveButton)
        updateButton = findViewById(R.id.updateButton)
        deleteButton = findViewById(R.id.deleteButton)

        // Save button action
        saveButton.setOnClickListener {
            val name = nameInput.text.toString().trim()
            val price = priceInput.text.toString().trim()
            val quantity = quantityInput.text.toString().trim()

            val id = productRef.push().key!!
            val product = Product(name, price, quantity, id)

            productRef.child(id).setValue(product).addOnSuccessListener {
                Toast.makeText(this, "Product saved!", Toast.LENGTH_SHORT).show()
                clearForm()
            }
        }

        // Update button action
        updateButton.setOnClickListener {
            val updated = Product(
                name = nameInput.text.toString().trim(),
                price = priceInput.text.toString().trim(),
                quantity = quantityInput.text.toString().trim(),
                id = selectedProductId ?: return@setOnClickListener
            )

            productRef.child(updated.id).setValue(updated).addOnSuccessListener {
                Toast.makeText(this, "Product updated!", Toast.LENGTH_SHORT).show()
                clearForm()
                saveButton.visibility = View.VISIBLE
                updateButton.visibility = View.GONE
                deleteButton.visibility = View.GONE
            }
        }

        // Delete button action
        deleteButton.setOnClickListener {
            selectedProductId?.let {
                productRef.child(it).removeValue().addOnSuccessListener {
                    Toast.makeText(this, "Product deleted", Toast.LENGTH_SHORT).show()
                    clearForm()
                    saveButton.visibility = View.VISIBLE
                    updateButton.visibility = View.GONE
                    deleteButton.visibility = View.GONE
                }
            }
        }

        // RecyclerView setup
        productList = mutableListOf()
        adapter = ProductAdapter(productList) { product ->
            nameInput.setText(product.name)
            priceInput.setText(product.price)
            quantityInput.setText(product.quantity)

            selectedProductId = product.id
            saveButton.visibility = View.GONE
            updateButton.visibility = View.VISIBLE
            deleteButton.visibility = View.VISIBLE
        }

        val recyclerView = findViewById<RecyclerView>(R.id.productRecyclerView)
        recyclerView.layoutManager = LinearLayoutManager(this)
        recyclerView.adapter = adapter

        // Firebase data listener
        productRef.addValueEventListener(object : ValueEventListener {
            override fun onDataChange(snapshot: DataSnapshot) {
                productList.clear()
                for (data in snapshot.children) {
                    val product = data.getValue(Product::class.java)
                    if (product != null) {
                        productList.add(product)
                    }
                }
                adapter.notifyDataSetChanged()
            }

            override fun onCancelled(error: DatabaseError) {
                Toast.makeText(this@MainActivity, "Failed to load products", Toast.LENGTH_SHORT).show()
            }
        })
    }

    private fun clearForm() {
        nameInput.setText("")
        priceInput.setText("")
        quantityInput.setText("")
    }
}
